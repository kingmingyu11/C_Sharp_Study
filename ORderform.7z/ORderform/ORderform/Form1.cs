﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ORderform
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

     
        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("민규전자");
            comboBox1.Items.Add("성일하이텍");
            comboBox1.Items.Add("세빗캠");
            comboBox1.Items.Add("고려아연");
            comboBox1.Items.Add("ANU");
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
           string selectedIndex = comboBox1.SelectedItem.ToString();
            string selectedIndex2 = comboBox2.SelectedItem.ToString();

            /*if (comboBox1.SelectedIndex == 0)
            {
                listBox1.Items.Add(selectedIndex);

            }
            else if (comboBox1.SelectedIndex == 1)
            {
                listBox1.Items.Add(selectedIndex);

            }
            else if (comboBox1.SelectedIndex == 2)
            {
                listBox1.Items.Add(selectedIndex);

            }
            else if (comboBox1.SelectedIndex == 3)
            {
                listBox1.Items.Add(selectedIndex);

            }*/

            if (comboBox1.SelectedIndex != -1)
                {
                   
                   
                        
                            if(comboBox2.SelectedIndex != -1)
                                          {
                   
                    
                   listBox1.Items.Add($"업체명: {selectedIndex}  주문상품 : {selectedIndex2}  개수:  {textBox1.Text}");
                                          
                }
                 }
                  
              
               

        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove(listBox1.SelectedItem);

            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string result = "";
                if (listBox1.SelectedIndex != -1)
                {
                    foreach (var input_items in listBox1.Items)
                    {
                        result += string.Format("{0}\r\n", input_items);
                    }
                    if (MessageBox.Show($"선택하신 품목이\r\n{result}\r\n맞으십니까?", "주문 확인", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        byte[] bytes = Encoding.UTF8.GetBytes(result);
                      
                        MessageBox.Show($"{result}\r\n주문 완료되었습니다.", "주문 완료");
                    }
                    else
                    {

                    }
                }
                else
                {
                    MessageBox.Show("물건이 추가되지 않았거나 물건이 없습니다.", "주문 실패");
                }

            }
            catch (Exception exception)
            {
                MessageBox.Show("서버 상태가 불안정합니다.", "주문 실패");
            }
        }
    }
    }

 

